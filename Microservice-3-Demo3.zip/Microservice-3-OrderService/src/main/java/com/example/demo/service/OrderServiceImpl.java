package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.OrderRepository;
import com.example.demo.dto.Order;


@Service
public class OrderServiceImpl implements OrderService {

	// Autowire the repository or any other dependencies here
	 @Autowired
	private OrderRepository orderRepository;

	@Override
	public Order createOrder(Order order) {
		// Logic to save the order using the repository
		 return orderRepository.save(order);
	}

	@Override
	public Order getOrderById(long id) {
		// Logic to retrieve the order by ID using the repository
		 return orderRepository.findById(id).orElse(null);
	}

	@Override
	public Order getOrderByUserId(long userid) {
		// TODO Auto-generated method stub
		return orderRepository.findByUserId(userid);
	}

}
