package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.CartRepository;
import com.example.demo.dto.Cart;

@Service
public class CartServiceImpl implements CartService {

	@Autowired CartRepository cartRepository;
	
	@Autowired OrderClient orderClient; 
	@Override
	public long saveCart(Cart cart) {
		Cart cartSaved=  cartRepository.save(cart);
		// Modify it later to return the created cart with a 201 status code and the location of the created resource in the response header		
		long orderId= orderClient.createOrder(cartSaved.getOrderRequest());
		return orderId;
	}
	@Override
	public Cart getCartByUserId(int userId) {
		return cartRepository.findByUserId(userId);
	}

	

}
