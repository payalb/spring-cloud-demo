package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.Cart;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {
	// This interface will automatically provide CRUD operations for User entities
	// No additional methods are needed unless custom queries are required
	public Cart findByUserId(int userId);

}
