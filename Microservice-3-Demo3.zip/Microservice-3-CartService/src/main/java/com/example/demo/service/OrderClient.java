package com.example.demo.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Config;
import com.example.demo.dto.OrderRequest;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@FeignClient(name = "Microservice-3-OrderService", configuration = Config.class)
public interface OrderClient {

	@PostMapping("/orders")
	@CircuitBreaker(name = "createOrder", fallbackMethod = "createOrderFallback")
	long createOrder(@RequestBody OrderRequest orderRequest);

	default long createOrderFallback(Exception exception) {
		System.out.println("⚠️ Fallback triggered due to: " + exception.getMessage());
		return -1;
	}	
}
