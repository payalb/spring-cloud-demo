package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.springframework.http.HttpStatus;

import com.example.demo.util.ExceptionMessage;

import feign.Response;
import feign.codec.ErrorDecoder;
import io.micrometer.core.instrument.util.IOUtils;

//Implements Feign’s ErrorDecoder interface to customize how errors are handled when HTTP requests fail (non-2xx responses).
public class CustomErrorDecoder implements ErrorDecoder {
//A fallback to the default error decoder for anything not explicitly handled.
    private final ErrorDecoder errorDecoder = new Default();

    //Customizes what should happen when a request fails. It attempts to read the body of the failed response and extract useful error info.
    // If the response body can be read, it constructs an ExceptionMessage object with details like the date, status code, reason phrase, and the error message.
    //You can configure your circuit breaker to ignore or handle specific exceptions.s
    @Override
    public Exception decode(String methodKey, Response response) {
        ExceptionMessage message = null;
        try (InputStream body = response.body().asInputStream()){
            message = new ExceptionMessage((String) response.headers().get("date").toArray()[0],
                    response.status(),
                    HttpStatus.resolve(response.status()).getReasonPhrase(),
                    IOUtils.toString(body, StandardCharsets.UTF_8),
                    response.request().url());

        } catch (IOException exception) {
            return new Exception(exception.getMessage());
        }
        switch (response.status()) {
            case 404:
                return new Exception(message.message() + " | Method Key: " + methodKey);
            default:
                return errorDecoder.decode(methodKey, response);
        }
    }
}