def print_func():
    print("hello")


print_func()
#2 blanks after class/ function def

def my_function(name):
    print(name)


my_function("Payal")
my_function("Ritu")

def add(*args):
    sum = 0
    for i in args:
        sum = sum + i
    print(sum)

add(2,3)
add(3,4,5)


def func2(name, age=20, address="Not assigned"):
    print("Person ", name, " staying at ", address, " is of age ", age)


func2(age=22, name="Ritu", address="Noida")


def my_function(**kid):
    print("His last name is " + kid["lname"])


my_function(fname="Tobias", lname="Refsnes")


def func_two():
    return "hello"


print(func_two())