i = 0
while i < 10:
    if i == 3:
        i = i + 2
        continue
    print(i)
    i = i + 1
    if i == 7:
        break
else:   #when condition becomes false
    print("out of loop")
# if while terminates normally, else executed, else no: not here
