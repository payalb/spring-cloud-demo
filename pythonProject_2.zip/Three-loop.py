my_list1 = list([2, 25, 36])
for i in my_list1:
    print(i)


my_list = tuple((1, 2, 3))
for i in range(0, len(my_list)):  #start is inclusive, stop exclusive
    print(my_list[i])

for i in range(0, len(my_list), 2):  #start, stop, step
    print(my_list[i])
