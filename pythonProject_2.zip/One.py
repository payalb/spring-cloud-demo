print("hello Python!")
#print your name
print("Hello Payal!")

#variables: dynamically typed
name= "payal"
address='noida'
print(name, address, 'hello')
#declare variable for your favourite fruit

#int , float, string, bool
x= 10
y = 23.5
z= 'Python'
is_fun= True
# what type is 7.0?

#Tuples: Immutable ordered collection: cannot change the values
my_tuple= (1,2,3)
print(my_tuple[0])

#lists: mutable ordered collection, can have duplicates
my_list=[1,2,3]  #dynamic array, stores references
print(my_list[0])
my_list[1] = 30
my_list.append(4)
print(my_list)
# add r favorite color to this list
my_list.append("yellow")
print(my_list)
#my_list.remove(2)  #error, if not in list
print(my_list)
# add ur favorite color one more time
my_list.append("yellow")
print(len(my_list))
my_list.insert(11, "red") #fine will insert in end, if index not there
print(my_list)
print(my_list.pop(0))  # removes    and returns the element at thos index
my_list.clear()
print(my_list.count(1)) # no of  times 1 appear in the list
my_list.sort()  #str.lower, abs, len,
my_list.reverse()
print(my_list)