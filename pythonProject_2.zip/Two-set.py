#set: unordered collection, unique elements, immutable
my_set= {1,2,3} #hashtable: key
print(my_set)
my_set.add(4)
print(my_set)
my_set.remove(2)
print(my_set)
new_set=my_set.copy()
print(my_set == new_set)
print(len(my_set))

for item in my_set:
    print(item)

#convert list to tuple:
list1= [1,2,3, 4,2]
tuple1= tuple(list1)
print(tuple1)

if 20 in my_set:
    print("present")