import os
import boto3
from flask import Flask, request, jsonify, send_file
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)

# AWS Config
AWS_REGION = os.getenv("AWS_REGION")
S3_BUCKET = os.getenv("S3_BUCKET_NAME")

s3_client = boto3.client(
    "s3",
    region_name=AWS_REGION,
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
)

# -------- UPLOAD FILE --------
@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    s3_client.upload_fileobj(file, S3_BUCKET, file.filename)

    return jsonify({"message": f"{file.filename} uploaded successfully!"})


# -------- DOWNLOAD FILE --------
@app.route("/download/<filename>", methods=["GET"])
def download_file(filename):
    local_path = f"/tmp/{filename}"

    try:
        s3_client.download_file(S3_BUCKET, filename, local_path)
    except Exception as e:
        return jsonify({"error": str(e)}), 404

    return send_file(local_path, as_attachment=True)


@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Flask S3 App Running!"})


if __name__ == "__main__":
    app.run(debug=True)
