package com.example.demo.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.dto.Cart;
import com.example.demo.service.CartService;

@WebMvcTest(CartController.class)
@ActiveProfiles("test")
public class CartControllerTest2 {

	 @Autowired
	    private MockMvc mockMvc;

	    @MockitoBean
	    private CartService cartService;

	    @Test
	    void testGetCartByUserId_Found() throws Exception {
	        Cart cart = new Cart();
	        cart.setUserId(1);
	        cart.setProducts(Map.of(101, "Apple", 102, "Banana"));

	        when(cartService.getCartByUserId(1)).thenReturn(cart);

	        mockMvc.perform(get("/users/1/cart"))
	               .andExpect(status().isOk())
	               .andExpect(jsonPath("$.userId").value(1))
	               .andExpect(jsonPath("$.products").isNotEmpty());
	    }

	    @Test
	    void testGetCartByUserId_NotFound() throws Exception {
	        when(cartService.getCartByUserId(99)).thenReturn(null);

	        mockMvc.perform(get("/users/99/cart"))
	               .andExpect(status().isNotFound());
	    }
	}