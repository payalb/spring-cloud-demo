package com.example.demo.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import com.example.demo.util.CartData;
import com.github.tomakehurst.wiremock.http.Fault;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import wiremock.com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
@AutoConfigureWireMock(port = 0)
public class CartControllerIT {

	@Autowired
	private MockMvc mockMvc;	
	
	@Autowired
	EntityManager entityManager;

	 private static final ObjectMapper objectMapper = new ObjectMapper();

	    public static String asJson(Object obj) {
	        try {
	            return objectMapper.writeValueAsString(obj);
	        } catch (Exception e) {
	            throw new RuntimeException(e);
	        }
	    }
	    
	@Test
	public void testSaveCartSuccess() throws Exception {
		entityManager.persist(CartData.getCartIdOne());	
		mockMvc.perform(get("/users/1/cart")).andExpect(status().isOk());
	}
	
	@Test
	public void testSaveCartFailure() throws Exception {
		stubFor(com.github.tomakehurst.wiremock.client.WireMock.post(urlPathMatching(".*\\/orders.*"))
			    .willReturn(aResponse().withFault(Fault.CONNECTION_RESET_BY_PEER)));
		mockMvc.perform(
		        post("/users/1/cart")
		            .contentType(MediaType.APPLICATION_JSON)
		            .content("{\"productId\": 123, \"quantity\": 2}")
		    )
				.andExpect(content().json("{\"orderId\": -1}"));
	}

}
