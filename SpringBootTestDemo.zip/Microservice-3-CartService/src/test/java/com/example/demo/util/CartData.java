package com.example.demo.util;

import java.util.Map;

import com.example.demo.dto.Cart;

public class CartData{
	
	public static Cart getCartIdOne() {
		Cart cart = new Cart(1);
		cart.setTotalPrice(100);
		cart.setProducts(Map.of(1, "Product1", 2, "Product2"));
		cart.setUserId(1);
		return cart;
	}

}
