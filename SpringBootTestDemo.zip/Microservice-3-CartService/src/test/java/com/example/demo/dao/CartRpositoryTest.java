package com.example.demo.dao;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import com.example.demo.dto.Cart;

@DataJpaTest
@ActiveProfiles("test")
public class CartRpositoryTest {

	@Autowired
	CartRepository cartRepository;

	@Autowired
	private TestEntityManager entityManager;

	@Test
	public void findByUserId_IdExistsTest() {
		Cart cart = new Cart(1);
		cart.setTotalPrice(100);
		cart.setProducts(Map.of(1, "Product1", 2, "Product2"));
		cart.setUserId(1);
		entityManager.persist(cart);
		Cart cartFound = cartRepository.findByUserId(1);
		assert (cartFound != null);
		assert (cartFound.getUserId() == 1);
		assert (cartFound.getProducts().size() == 2);
	}

	@Test
	public void findByUserId_IdNotExistsTest() {
		Cart cartFound = cartRepository.findByUserId(1);
		assert (cartFound == null);
	}
	
	@Test
	public void findProductNameCustomQuery_ProductExistsTest() {
		Cart cart = new Cart(1);
		cart.setTotalPrice(100);
		cart.setProducts(Map.of(1, "Product1", 2, "Product2"));
		cart.setUserId(1);
		entityManager.persist(cart);
		var cartsFound = cartRepository.findProductNameCustomQuery("Product1");
		assert(cartsFound.size() == 1);
		assert(cartsFound.get(0).getUserId() == 1);
	}
}
