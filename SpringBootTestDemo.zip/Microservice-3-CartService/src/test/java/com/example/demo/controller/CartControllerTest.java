package com.example.demo.controller;

import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.dto.Cart;
import com.example.demo.dto.OrderResponse;
import com.example.demo.service.CartService;

@ExtendWith(MockitoExtension.class)
public class CartControllerTest {
	
	@Mock CartService cartService;
	
	@InjectMocks CartController cartController;
	
	@Test
	public void saveCartTest() {
		Cart cart = new Cart(1);
		cart.setTotalPrice(100);
		cart.setProducts(Map.of(1, "Product1", 2, "Product2"));
		cart.setUserId(1);
		when(cartService.saveCart(cart)).thenReturn(new OrderResponse(1L));
		ResponseEntity<OrderResponse> cartEntity = cartController.saveCart(cart);
		System.out.println(cartEntity.getBody());
		assert(cartEntity.getStatusCode() == HttpStatus.CREATED);
		assert(cartEntity.getBody().getOrderId() == 1L);
	}

}
