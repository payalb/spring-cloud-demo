package com.example.demo.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.dao.CartRepository;
import com.example.demo.dto.Cart;
import com.example.demo.dto.OrderResponse;

@ExtendWith(MockitoExtension.class)
public class CartServiceTest {

	@Mock CartRepository cartRepository;
	@Mock OrderClient orderClient;
	@InjectMocks CartServiceImpl cartService;
	
	@Test
	public void testSaveCart() {
		when(cartRepository.save(any(Cart.class))).thenReturn(new Cart());
		when(orderClient.createOrder(any())).thenReturn(new OrderResponse(1L));
		OrderResponse id = cartService.saveCart(new Cart());
		assertThat(id.getOrderId() ).isEqualTo(1L);
	}
}	
