package com.example.demo.service;

import com.example.demo.dto.Cart;
import com.example.demo.dto.OrderResponse;

public interface CartService {

	/**
	 * Creates a new user in the system.
	 *
	 * @param user The user object containing user details.
	 * @return The created user object.
	 */

	public OrderResponse saveCart(Cart cart);

	public Cart getCartByUserId(int userId);
}
