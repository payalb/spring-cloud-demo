package com.example.demo.util;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.example.demo.dao.CartRepository;
import com.example.demo.dto.Cart;

@Component
@Profile("!test") // Disable seeding when 'test' profile is active
public class DataSeeder implements CommandLineRunner{

    @Autowired CartRepository cartRepository;

    @Override
    public void run(String... args) throws Exception {
        Cart cart = new Cart(1);
        cart.setProducts(Map.of(1, "Product1", 2, "Product2"));
        cart.setTotalPrice(100.0f);
        cartRepository.save(cart);
        System.out.println("Data seeding is not implemented yet.");
    }
}
