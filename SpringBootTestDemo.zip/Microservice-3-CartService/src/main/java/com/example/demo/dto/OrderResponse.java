package com.example.demo.dto;

public class OrderResponse {
	
	long orderId;

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public OrderResponse() {
		super();
	}

	public OrderResponse(long orderId) {
		super();
		this.orderId = orderId;
	}

	
}
