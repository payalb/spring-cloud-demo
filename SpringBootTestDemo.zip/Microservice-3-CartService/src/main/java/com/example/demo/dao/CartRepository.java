package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.dto.Cart;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

	//public Cart findByUserIds(int userId); 
	//At runtime will throw an exception if no property is found with the given name
	
	public Cart findByUserId(int userId);
	
	//Find carts containing a specific product name
	@Query("SELECT c FROM Cart c JOIN c.products p WHERE VALUE(p) = :productName")
	List<Cart> findProductNameCustomQuery(@Param("productName") String productName);
	
	@Query("SELECT c FROM Cart c JOIN c.products p WHERE KEY(p) = :productId")
	List<Cart> findByProductIdCustomQUery(@Param("productId") int productId);
}
