package com.example.demo.dto;

import java.util.ArrayList;
import java.util.List;

public class OrderRequest {
	
	//change it to enum later	
		private String status;
		private List<String> items= new ArrayList<>();
		private int userId;
		private float price;
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public List<String> getItems() {
			return items;
		}
		public void setItems(List<String> items) {
			this.items = items;
		}
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}

}
