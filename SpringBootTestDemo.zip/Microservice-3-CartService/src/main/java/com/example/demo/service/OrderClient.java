package com.example.demo.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.dto.OrderRequest;
import com.example.demo.dto.OrderResponse;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@FeignClient(name = "Microservice-3-OrderService")
public interface OrderClient {

	@PostMapping("/orders")
	@CircuitBreaker(name = "createOrder", fallbackMethod = "createOrderFallback")
	OrderResponse createOrder(@RequestBody OrderRequest orderRequest);

	default OrderResponse createOrderFallback(Exception exception) {
		System.out.println("⚠️ Fallback triggered due to: " + exception.getMessage());
		return new OrderResponse(-1); // Indicate failure with a special ID
	}	
}
