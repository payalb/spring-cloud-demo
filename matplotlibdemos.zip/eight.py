#Titles, labels, legend, grid, limits
import matplotlib.pyplot as plt
fig, ax = plt.subplots()
ax.plot([1, 2, 3], [3, 2, 5], label="Series 1")
ax.plot([1, 2, 3], [2, 3, 4], label="Series 2")

ax.set_title("Titles & Labels")
ax.set_xlabel("X axis")
ax.set_ylabel("Y axis")
ax.legend()                 # show curve names from label=
ax.grid(True)               # show gridlines
ax.set_xlim(0, 4)           # x-range
ax.set_ylim(0, 6)           # y-range
plt.show()
