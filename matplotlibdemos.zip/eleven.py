#Secondary axis (two scales)
import matplotlib.pyplot as plt
fig, ax1 = plt.subplots()
x = [0, 1, 2, 3]
y1 = [0, 10, 20, 25]     # primary axis
y2 = [0, 1,  2,  2.5]    # secondary axis

ax1.plot(x, y1, color="blue", label="Main Data", linestyle="-")
ax1.set_xlabel("x")
ax1.set_ylabel("main")

ax2 = ax1.twinx()        # share x, new y
ax2.plot(x, y2, color="red", linestyle="--", label="Secondary Data")
ax2.set_ylabel("secondary")
plt.show()
