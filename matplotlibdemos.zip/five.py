#horizontal bar
import matplotlib.pyplot as plt
cities = ["Delhi", "Mumbai", "Chennai"]
sales  = [120,  95,   70]
fig, ax = plt.subplots()
ax.barh(cities, sales) #barh
ax.set_title("Sales by City (horizontal)")
ax.set_xlabel("Sales")
plt.show()
