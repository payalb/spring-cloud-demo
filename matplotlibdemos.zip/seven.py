#pie chart
import matplotlib.pyplot as plt
labels = ["A", "B", "C"]
sizes  = [50, 30, 20]

fig, ax = plt.subplots()
ax.pie(sizes, labels=labels, autopct="%1.1f%%")  # show percentages
ax.set_title("Pie")
ax.axis("equal")  # make it a circle
plt.show()
