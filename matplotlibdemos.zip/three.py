#scatter plot
import matplotlib.pyplot as plt
heights = [150, 160, 170, 180, 190]
weights = [50, 54, 63, 80, 90]

fig, ax = plt.subplots()
ax.scatter(heights, weights)
ax.set_title("Scatter")
ax.set_xlabel("Height (cm)")
ax.set_ylabel("Weight (kg)")
plt.show()
