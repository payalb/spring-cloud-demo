# error plots
import matplotlib.pyplot as plt
x = [1, 2, 3, 4]
y = [10, 12, 9, 14]
err = [1, 0.5, 1.5, 0.7]

fig, ax = plt.subplots()
ax.errorbar(x, y, yerr=err, fmt="o-")   # fmt controls marker/line style
ax.set_title("Error bars")
plt.show()
