import matplotlib.pyplot as plt
# plt.subplot(nrows, ncols, plot_number)
x = [0, 1, 2, 3]
y = [0, 10, 20, 25]     # primary axis
plt.subplot(1,2,1)
plt.plot(x, y, 'r--') # More on color options later
plt.subplot(1,2,2)
plt.plot(y, x, 'g*-');
plt.show()
