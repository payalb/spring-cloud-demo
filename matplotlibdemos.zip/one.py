import matplotlib.pyplot as plt

fig, ax = plt.subplots()          # make a Figure and one Axes
ax.plot([1, 2, 3], [3, 2, 5])
ax.set_title("My first plot")
ax.set_xlabel("X")
ax.set_ylabel("Y")
plt.show()
