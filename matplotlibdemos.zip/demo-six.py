#Histogram
import matplotlib.pyplot as plt
data = [12, 15, 14, 18, 21, 17, 16, 14, 19, 22, 13, 18]

fig, ax = plt.subplots()
ax.hist(data, bins=5,edgecolor="black" )   # bins = means we split the data into 5 groups (intervals).
#Example: 12–14, 15–17, 18–20, etc.
ax.set_title("Histogram")
ax.set_xlabel("Value")

ax.set_ylabel("Count")
plt.show()
