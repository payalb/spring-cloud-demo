# Dates & categories
import pandas as pd
import matplotlib.pyplot as plt
dates = pd.date_range("2025-01-01", periods=5, freq="D")
values = [1, 3, 2, 5, 4]

fig, ax = plt.subplots()
ax.plot(dates, values)
fig.autofmt_xdate()   # rotate/format date labels nicely
plt.show()
