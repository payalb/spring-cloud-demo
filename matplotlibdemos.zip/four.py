#bar graph
import matplotlib.pyplot as plt
cities = ["Delhi", "Mumbai", "Chennai"]
sales  = [120,  95,   70]

fig, ax = plt.subplots()
ax.bar(cities, sales)
ax.set_title("Bar Graph")
ax.set_xlabel("Sales by City")
ax.set_ylabel("Sales")
plt.show()
