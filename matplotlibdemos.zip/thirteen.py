import matplotlib.pyplot as plt
fig, ax = plt.subplots()
ax.plot([1,2,3], [2,4,1])
fig.savefig("my_plot.png", dpi=200, bbox_inches="tight")   # png/jpg/pdf/svg
plt.show()
