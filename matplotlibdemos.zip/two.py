#line graph with marker
import matplotlib.pyplot as plt
x = [0, 1, 2, 3, 4]
y = [0, 1, 4, 9, 16]

fig, ax = plt.subplots()
ax.plot(x, y, marker="o", linestyle="-")  # markers show each point
ax.set_title("Line plot")
ax.set_xlabel("x")
ax.set_ylabel("y")
plt.show()
