#Ticks & formatting
import matplotlib.pyplot as plt
fig, ax = plt.subplots()
ax.plot([0, 1, 2, 3], [10, 20, 15, 30])
ax.set_title("Ticks and formatting")
ax.set_xticks([0, 1, 2, 3])                 # where ticks go
ax.set_xticklabels(["Zero", "One", "Two", "Three"])  # how ticks look
ax.tick_params(axis="x", rotation=30)       # rotate labels if crowded
plt.show()
